package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.Stat;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.Vec3;

/** Handles every request a client can send. Nothing here trusts the client: all values are re-checked. */
import java.util.List;

public final class ServerActions {
    /** Chakra needed to switch on Sharingan/Byakugan. */
    public static final float DOJUTSU_MIN_CHAKRA = 5f;

    private ServerActions() {}

    public static void handle(ServerPlayer player, int action, int arg, int arg2) {
        NinjaData data = NinjaData.get(player);
        if (data == null || !data.isInitialized()) return;
        switch (action) {
            case ActionPacket.CAST -> JutsuCaster.tryCast(player);
            case ActionPacket.NEXT -> moveArrow(player, data, 1);
            case ActionPacket.PREV -> moveArrow(player, data, -1);
            case ActionPacket.DOJUTSU -> toggleDojutsu(player, data);
            case ActionPacket.CHARGE_START -> {
                if (!data.isCharging()) {
                    data.setCharging(true);
                    JutsuUtil.sound(player.level(), player.position(), SoundEvents.BEACON_AMBIENT, 0.8f, 1.6f);
                    ModNetwork.sync(player);
                }
            }
            case ActionPacket.CHARGE_STOP -> {
                if (data.isCharging()) {
                    data.setCharging(false);
                    ModNetwork.sync(player);
                }
            }
            case ActionPacket.NINJA_JUMP -> ninjaJump(player, data);
            case ActionPacket.TEAM_LEAVE -> {
                Component msg = com.shinobiarts.team.TeamManager.get(player.server).leave(player);
                if (!msg.getString().isEmpty()) player.sendSystemMessage(msg);
            }
            case ActionPacket.SAGE_MODE -> toggleSageMode(player, data);
            case ActionPacket.ALLOCATE_STAT -> {
                if (arg >= 0 && arg < Stat.values().length) PlayerDataManager.allocate(player, Stat.values()[arg], Math.min(arg2, 100));
            }
            case ActionPacket.RESET_STATS -> PlayerDataManager.resetStats(player);
            case ActionPacket.UPGRADE_JUTSU -> {
                Jutsu jutsu = Jutsus.byIndex(arg);
                if (jutsu != null) PlayerDataManager.upgradeJutsu(player, jutsu);
            }
            case ActionPacket.DEPOSIT -> PlayerDataManager.deposit(player, arg < 0 ? null : CoinItem.Coin.byOrdinal(arg));
            case ActionPacket.WITHDRAW -> {
                CoinItem.Coin coin = CoinItem.Coin.byOrdinal(arg);
                if (coin != null) PlayerDataManager.withdraw(player, coin, arg2);
            }
            default -> {
            }
        }
    }

    /** Moves the selection arrow inside the release the player is holding. */
    private static void moveArrow(ServerPlayer player, NinjaData data, int direction) {
        ChakraNature release = ReleaseItem.heldRelease(player);
        if (release == null) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.hold_release").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (data.slots(release).isEmpty()) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.release_empty", release.displayName()).withStyle(ChatFormatting.GRAY), true);
            return;
        }
        data.moveSlot(release, direction);
        Jutsu selected = data.selectedJutsu(release);
        if (selected != null) player.displayClientMessage(selected.displayName(), true);
        ModNetwork.sync(player);
    }

    /** V: off -> first owned eye -> next owned eye -> off (most players own just one). */
    private static void toggleDojutsu(ServerPlayer player, NinjaData data) {
        List<Dojutsu> owned = data.availableDojutsu();
        if (owned.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.no_dojutsu").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        Dojutsu current = data.getActiveDojutsu();
        int index = owned.indexOf(current);
        Dojutsu next = current == Dojutsu.NONE ? owned.get(0) : (index >= 0 && index + 1 < owned.size() ? owned.get(index + 1) : Dojutsu.NONE);
        if (next != Dojutsu.NONE && data.getChakra() < DOJUTSU_MIN_CHAKRA && !player.getAbilities().instabuild) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                    (int) data.getChakra(), (int) DOJUTSU_MIN_CHAKRA).withStyle(ChatFormatting.RED), true);
            return;
        }
        if (current == Dojutsu.BYAKUGAN) player.removeEffect(MobEffects.NIGHT_VISION);
        data.setActiveDojutsu(next);
        if (next == Dojutsu.NONE) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.dojutsu_off", data.dojutsuName(current)), true);
            JutsuUtil.sound(player.level(), player.position(), SoundEvents.BEACON_DEACTIVATE, 0.6f, 1.8f);
        } else {
            NinjaTicker.applyDojutsu(player, data);
            player.displayClientMessage(Component.translatable("message.shinobiarts.dojutsu_on", data.dojutsuName(next)), true);
            JutsuUtil.sound(player.level(), player.position(), SoundEvents.BEACON_ACTIVATE, 0.6f, 1.8f);
        }
        ModNetwork.sync(player);
        SharinganManager.broadcastEyes(player);
    }

    private static void toggleSageMode(ServerPlayer player, NinjaData data) {
        if (data.isSageMode()) {
            data.setSageMode(false);
            player.displayClientMessage(Component.translatable("message.shinobiarts.sage_off").withStyle(ChatFormatting.DARK_GREEN), true);
            ModNetwork.sync(player);
            return;
        }
        if (data.maxSenjutsu() <= 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.no_senjutsu").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        int needed = Config.i(Config.SAGE_MODE_MIN);
        if (data.getSenjutsu() < needed) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.low_senjutsu", (int) data.getSenjutsu(), needed)
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        data.setSageMode(true);
        NinjaTicker.applySageMode(player);
        player.serverLevel().sendParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1, player.getZ(), 40, 0.6, 0.8, 0.6, 0.1);
        JutsuUtil.sound(player.level(), player.position(), SoundEvents.FROG_AMBIENT, 1.0f, 0.8f);
        player.displayClientMessage(Component.translatable("message.shinobiarts.sage_on").withStyle(ChatFormatting.GREEN), true);
        ModNetwork.sync(player);
    }

    /** Shift + Jump (from the ground): costs chakra, launches you forward and up, then a short speed boost. No cooldown. */
    private static void ninjaJump(ServerPlayer player, NinjaData data) {
        if (player.isSpectator() || player.getAbilities().flying || player.isPassenger() || player.isFallFlying()) return;
        long now = player.level().getGameTime();
        boolean creative = player.getAbilities().instabuild;
        int cost = Config.i(Config.NINJA_JUMP_COST);
        if (!creative && data.getChakra() < cost) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                    (int) data.getChakra(), cost).withStyle(ChatFormatting.RED), true);
            return;
        }
        if (!creative) data.consumeChakra(cost);
        data.setFallProtectUntil(now + 80);

        double power = Config.d(Config.NINJA_JUMP_POWER);
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1e-4 ? Vec3.ZERO : flat.normalize();
        player.setDeltaMovement(flat.x * 1.25 * power, 0.85 * power, flat.z * 1.25 * power);
        player.hasImpulse = true;
        player.hurtMarked = true;
        player.resetFallDistance();
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 50, 1, false, false, true));

        player.serverLevel().sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.1, player.getZ(), 20, 0.4, 0.05, 0.4, 0.05);
        JutsuUtil.sound(player.level(), player.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 0.7f, 1.7f);
        ModNetwork.sync(player);
    }
}
