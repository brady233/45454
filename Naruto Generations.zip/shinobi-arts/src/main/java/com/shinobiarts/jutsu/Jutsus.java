package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.shinobiarts.ninja.ChakraNature.EARTH;
import static com.shinobiarts.ninja.ChakraNature.FIRE;
import static com.shinobiarts.ninja.ChakraNature.LIGHTNING;
import static com.shinobiarts.ninja.ChakraNature.NONE;
import static com.shinobiarts.ninja.ChakraNature.WATER;
import static com.shinobiarts.ninja.ChakraNature.WIND;
import static com.shinobiarts.ninja.ChakraNature.YIN_YANG;
import static com.shinobiarts.jutsu.JutsuRank.A;
import static com.shinobiarts.jutsu.JutsuRank.B;
import static com.shinobiarts.jutsu.JutsuRank.C;
import static com.shinobiarts.jutsu.JutsuRank.D;
import static com.shinobiarts.jutsu.JutsuRank.S;

/**
 * Every jutsu in the mod. To add one: register it here, implement its effect in {@link JutsuEffects},
 * then add its name, description and recipe to tools/make_resources.py and run it.
 * A jutsu goes into the slots of its nature's release; clan and non-elemental jutsu go into Ninjutsu.
 * Cooldowns are in ticks (20 ticks = 1 second).
 */
public final class Jutsus {
    private static final Map<String, Jutsu> BY_ID = new LinkedHashMap<>();
    private static final Collection<Jutsu> ALL = Collections.unmodifiableCollection(BY_ID.values());

    // Ranks follow the show where it gives one (Narutopedia / databooks); unranked jutsu are placed by strength.
    // Every jutsu costs the same share of max chakra ("jutsuCostPercent" in the config, 15% by default).
    //                                       id                    nature     clan          rank cooldown needs eyes
    // Fire Release
    public static final Jutsu FIREBALL          = reg("fireball",          FIRE,      null,         C,    30,  false, JutsuEffects::fireball);
    public static final Jutsu PHOENIX_FLOWER    = reg("phoenix_flower",    FIRE,      null,         C,    40,  false, JutsuEffects::phoenixFlower);
    public static final Jutsu FIRE_ANNIHILATION = reg("fire_annihilation", FIRE,      null,         B,   120,  false, JutsuEffects::fireAnnihilation);
    // Water Release
    public static final Jutsu WATER_BULLET      = reg("water_bullet",      WATER,     null,         D,    15,  false, JutsuEffects::waterBullet);
    public static final Jutsu WATER_PRISON      = reg("water_prison",      WATER,     null,         C,   160,  false, JutsuEffects::waterPrison);
    public static final Jutsu WATER_DRAGON      = reg("water_dragon",      WATER,     null,         B,   100,  false, JutsuEffects::waterDragon);
    // Wind Release
    public static final Jutsu GALE_PALM         = reg("gale_palm",         WIND,      null,         C,    20,  false, JutsuEffects::galePalm);
    public static final Jutsu VACUUM_BLADE      = reg("vacuum_blade",      WIND,      null,         B,    30,  false, JutsuEffects::vacuumBlade);
    public static final Jutsu GREAT_BREAKTHROUGH= reg("great_breakthrough",WIND,      null,         C,   100,  false, JutsuEffects::greatBreakthrough);
    public static final Jutsu RASENSHURIKEN     = reg("rasenshuriken",     WIND,      null,         S,   300,  false, JutsuEffects::rasenshuriken);
    // Lightning Release
    public static final Jutsu LIGHTNING_ARMOR   = reg("lightning_armor",   LIGHTNING, null,         A,   480,  false, JutsuEffects::lightningArmor);
    public static final Jutsu CHIDORI           = reg("chidori",           LIGHTNING, null,         A,    80,  false, JutsuEffects::chidori);
    public static final Jutsu THUNDER_STRIKE    = reg("thunder_strike",    LIGHTNING, null,         A,   150,  false, JutsuEffects::thunderStrike);
    // Earth Release
    public static final Jutsu EARTH_WALL        = reg("earth_wall",        EARTH,     null,         B,   100,  false, JutsuEffects::earthWall);
    public static final Jutsu ROCK_ARMOR        = reg("rock_armor",        EARTH,     null,         B,   480,  false, JutsuEffects::rockArmor);
    public static final Jutsu EARTH_SPIKES      = reg("earth_spikes",      EARTH,     null,         B,    50,  false, JutsuEffects::earthSpikes);
    // Yin Yang Release: Yin illusions (stronger with Genjutsu) and Yang healing (stronger with Medical)
    public static final Jutsu HELL_VIEWING      = reg("hell_viewing",      YIN_YANG,       null,         D,   100,  false, JutsuEffects::hellViewing);
    public static final Jutsu MIND_FOG          = reg("mind_fog",          YIN_YANG,       null,         C,   200,  false, JutsuEffects::mindFog);
    public static final Jutsu MYSTICAL_PALM     = reg("mystical_palm",     YIN_YANG,      null,         A,   100,  false, JutsuEffects::mysticalPalm);
    public static final Jutsu VITALITY_SURGE    = reg("vitality_surge",    YIN_YANG,      null,         S,   480,  false, JutsuEffects::vitalitySurge);
    // Non-elemental (Ninjutsu release)
    public static final Jutsu SUBSTITUTION      = reg("substitution",      NONE,      null,         D,   160,  false, JutsuEffects::substitution);
    public static final Jutsu BODY_FLICKER      = reg("body_flicker",      NONE,      null,         D,    30,  false, JutsuEffects::bodyFlicker);
    public static final Jutsu SHADOW_CLONE      = reg("shadow_clone",      NONE,      null,         B,   200,  false, JutsuEffects::shadowClone);
    public static final Jutsu RASENGAN          = reg("rasengan",          NONE,      null,         A,   100,  false, JutsuEffects::rasengan);
    // Clan techniques (Amaterasu: anyone with a Sharingan can learn it; casting needs an active Mangekyou)
    public static final Jutsu SHADOW_POSSESSION = reg("shadow_possession", NONE,      Clan.NARA,    C,   180,  false, JutsuEffects::shadowPossession);
    public static final Jutsu PALM_ROTATION     = reg("palm_rotation",     NONE,      Clan.HYUGA,   A,   100,  false, JutsuEffects::palmRotation);
    public static final Jutsu AMATERASU         = reg("amaterasu",         NONE,      null,         S,   600,  true,  JutsuEffects::amaterasu);

    private static Jutsu reg(String id, ChakraNature nature, @Nullable Clan clan, JutsuRank rank, int cooldown, boolean needsDojutsu, Jutsu.Action action) {
        Jutsu jutsu = new Jutsu(id, nature, clan, rank, cooldown, needsDojutsu, action);
        if (BY_ID.put(id, jutsu) != null) throw new IllegalStateException("Duplicate jutsu id " + id);
        return jutsu;
    }

    @Nullable
    public static Jutsu get(String id) {
        return BY_ID.get(id);
    }

    public static Collection<Jutsu> all() {
        return ALL;
    }

    /** Jutsu that deal damage: the ones Jutsu Points can upgrade. */
    private static final java.util.Set<String> DAMAGING = java.util.Set.of(
            "fireball", "phoenix_flower", "fire_annihilation", "water_bullet", "water_prison", "water_dragon",
            "gale_palm", "vacuum_blade", "great_breakthrough", "rasenshuriken", "chidori", "thunder_strike",
            "earth_spikes", "hell_viewing", "rasengan", "palm_rotation", "amaterasu");

    public static boolean upgradeable(Jutsu jutsu) {
        return DAMAGING.contains(jutsu.id());
    }

    /** Position in registration order: how the client names a jutsu in packets (same on both sides). */
    public static int index(Jutsu jutsu) {
        int i = 0;
        for (Jutsu j : ALL) {
            if (j == jutsu) return i;
            i++;
        }
        return -1;
    }

    @Nullable
    public static Jutsu byIndex(int index) {
        int i = 0;
        for (Jutsu j : ALL) {
            if (i++ == index) return j;
        }
        return null;
    }

    private Jutsus() {}
}
