package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.shinobiarts.Config;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.Stat;
import com.shinobiarts.village.Villages;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * The ninja info menu (J), drawn as a pale ninja-record panel: stats on the left with "+" buttons
 * (shift-click adds 5), clan, village, rank, natures and kekkei genkai on the right, and an XP strip below.
 * Tabs switch to the team page and the Jutsu page, where Jutsu Points upgrade a jutsu's damage.
 * The server validates every click.
 */
public class StatScreen extends Screen {
    static final int PANEL = 0xFFE4E9D8, BORDER = 0xFF98A389, LIGHT = 0xFFF7F9F1, LINE = 0xFFBAC4AC, INK = 0xFF262626, INK_SOFT = 0xFF5E6455;
    private static final int W = 330, H = 196, ROW_H = 18;
    private static final int STATS = 0, TEAM = 1, JUTSU = 2;
    private static final int JROWS = 7, JROW_H = 19;

    private static int page;
    private static int jutsuPage;
    private final Map<Stat, Button> plusButtons = new EnumMap<>(Stat.class);
    private final List<Jutsu> shownJutsu = new ArrayList<>();
    private final List<Button> upgradeButtons = new ArrayList<>();
    private int knownCount = -1;
    private Button resetButton;
    private Button leaveTeamButton;
    private int left;
    private int top;

    public StatScreen() {
        super(Component.translatable("screen.shinobiarts.stats"));
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2 + 10;
        top = Math.max(14, (this.height - H - 30) / 2);
        for (Stat stat : Stat.values()) {
            int y = top + 22 + stat.ordinal() * ROW_H;
            Button plus = Button.builder(Component.literal("+"), b -> {
                        int amount = hasShiftDown() ? 5 : 1;
                        ModNetwork.toServer(new ActionPacket(ActionPacket.ALLOCATE_STAT, stat.ordinal(), amount));
                    })
                    .bounds(left - 20, y - 2, 16, 15)
                    .tooltip(Tooltip.create(stat.description().copy().append("\n")
                            .append(Component.translatable("screen.shinobiarts.shift_add").withStyle(ChatFormatting.GRAY))))
                    .build();
            plusButtons.put(stat, plus);
            addRenderableWidget(plus);
        }
        resetButton = addRenderableWidget(Button.builder(Component.empty(),
                        b -> this.minecraft.setScreen(new ResetConfirmScreen(this)))
                .bounds(left + 172, top + H - 26, W - 182, 18).build());
        leaveTeamButton = addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.team_leave"),
                        b -> ModNetwork.toServer(new ActionPacket(ActionPacket.TEAM_LEAVE)))
                .bounds(left + 172, top + H - 26, W - 182, 18).build());
        String[] tabs = {"screen.shinobiarts.tab_stats", "screen.shinobiarts.tab_team", "screen.shinobiarts.tab_jutsu"};
        for (int i = 0; i < tabs.length; i++) {
            int index = i;
            Button tab = addRenderableWidget(Button.builder(Component.translatable(tabs[i]), b -> {
                page = index;
                rebuildWidgets();
            }).bounds(left + W - 140 + i * 46, top - 16, 44, 14).build());
            tab.active = i != page;
        }

        // Jutsu page: one "Upgrade" button per row, and page arrows when there are more than fit
        shownJutsu.clear();
        upgradeButtons.clear();
        List<Jutsu> all = upgradeableJutsu(ClientNinjaData.get());
        knownCount = all.size();
        int pages = Math.max(1, (all.size() + JROWS - 1) / JROWS);
        jutsuPage = Math.min(jutsuPage, pages - 1);
        if (page == JUTSU) {
            for (int i = jutsuPage * JROWS; i < Math.min(all.size(), (jutsuPage + 1) * JROWS); i++) {
                Jutsu jutsu = all.get(i);
                int ry = top + 38 + (i - jutsuPage * JROWS) * JROW_H;
                shownJutsu.add(jutsu);
                upgradeButtons.add(addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.upgrade"),
                                b -> ModNetwork.toServer(new ActionPacket(ActionPacket.UPGRADE_JUTSU, Jutsus.index(jutsu), 0)))
                        .bounds(left + W - 70, ry - 3, 62, 15).build()));
            }
            if (pages > 1) {
                addRenderableWidget(Button.builder(Component.literal("<"), b -> {
                    jutsuPage = Math.max(0, jutsuPage - 1);
                    rebuildWidgets();
                }).bounds(left + W / 2 - 34, top + H - 20, 20, 14).build()).active = jutsuPage > 0;
                addRenderableWidget(Button.builder(Component.literal(">"), b -> {
                    jutsuPage = Math.min(pages - 1, jutsuPage + 1);
                    rebuildWidgets();
                }).bounds(left + W / 2 + 14, top + H - 20, 20, 14).build()).active = jutsuPage < pages - 1;
            }
        }
        refresh();
    }

    /** The player's learned jutsu that deal damage, in release order. */
    private static List<Jutsu> upgradeableJutsu(NinjaData d) {
        List<Jutsu> out = new ArrayList<>();
        for (Jutsu j : Jutsus.all()) {
            if (d.knows(j.id()) && Jutsus.upgradeable(j)) out.add(j);
        }
        return out;
    }

    private void refresh() {
        NinjaData d = ClientNinjaData.get();
        for (Stat stat : Stat.values()) {
            Button b = plusButtons.get(stat);
            b.visible = page == STATS;
            b.active = d.availablePoints() > 0 && d.stat(stat) < stat.cap();
        }
        resetButton.setMessage(Component.translatable("screen.shinobiarts.reset_button", PlayerDataManager.formatRyo(d.resetCost())));
        resetButton.visible = page == STATS;
        resetButton.active = d.allocatedPoints() > 0;
        leaveTeamButton.visible = page == TEAM && ClientNinjaData.team().contains("Name");
        int cost = Config.i(Config.JUTSU_UPGRADE_COST), max = Config.i(Config.JUTSU_MAX_UPGRADES);
        for (int i = 0; i < upgradeButtons.size(); i++) {
            boolean maxed = d.jutsuUpgrade(shownJutsu.get(i).id()) >= max;
            Button b = upgradeButtons.get(i);
            b.setMessage(Component.translatable(maxed ? "screen.shinobiarts.upgrade_max" : "screen.shinobiarts.upgrade"));
            b.active = !maxed && d.getJutsuPoints() >= cost;
        }
    }

    @Override
    public void tick() {
        // learning a jutsu while the menu is open adds a row
        if (upgradeableJutsu(ClientNinjaData.get()).size() != knownCount) rebuildWidgets();
        refresh();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        NinjaData d = ClientNinjaData.get();
        panel(g, left, top, W, H);
        panel(g, left, top + H + 4, W, 22);

        // nature icon medallion at the top, like a ninja record's seal
        ChakraNature seal = d.isAffinityRevealed() ? d.getAffinity() : ChakraNature.NONE;
        int cx = left + W / 2;
        g.fill(cx - 10, top - 10, cx + 10, top + 10, BORDER);
        g.fill(cx - 9, top - 9, cx + 9, top + 9, LIGHT);
        RenderSystem.enableBlend();
        g.blit(seal.icon(), cx - 8, top - 8, 16, 16, 0, 0, 64, 64, 64, 64);

        if (page == TEAM) renderTeamPage(g);
        else if (page == JUTSU) renderJutsuPage(g, d);
        else renderStatsPage(g, d, mouseX, mouseY);

        // XP strip
        int barX = left + 10, barY = top + H + 15, barW = W - 150;
        float frac = d.isMaxLevel() ? 1f : Math.min(1f, d.getXp() / (float) Math.max(1, d.xpToNext()));
        g.fill(barX - 1, barY - 1, barX + barW + 1, barY + 4, 0xFF8E9980);
        g.fill(barX, barY, barX + barW, barY + 3, 0xFFF4F6EE);
        g.fill(barX, barY, barX + Math.round(barW * frac), barY + 3, 0xFF6FBF4F);
        Component xp = d.isMaxLevel() ? Component.translatable("screen.shinobiarts.rank_capped")
                : Component.translatable("screen.shinobiarts.exp", d.getXp(), d.xpToNext());
        g.drawString(this.font, xp, barX + barW / 2 - this.font.width(xp) / 2, top + H + 6, INK, false);
        Component lvl = Component.translatable("screen.shinobiarts.lvl", d.getLevel());
        g.drawString(this.font, lvl, barX + barW + 8, top + H + 11, INK, false);
        Component pts = Component.translatable("screen.shinobiarts.skill", d.availablePoints());
        g.drawString(this.font, pts, left + W - 8 - this.font.width(pts), top + H + 11, d.availablePoints() > 0 ? 0xFF1E7A2E : INK, false);

        super.render(g, mouseX, mouseY, partialTick);
    }

    private void renderStatsPage(GuiGraphics g, NinjaData d, int mouseX, int mouseY) {
        int x = left + 8, y = top + 22;
        g.drawString(this.font, Component.translatable("screen.shinobiarts.stats"), x, top + 8, INK_SOFT, false);
        g.fill(left + 164, top + 8, left + 165, top + H - 8, LINE);
        Stat hovered = null;
        for (Stat stat : Stat.values()) {
            int ry = y + stat.ordinal() * ROW_H;
            if (stat.ordinal() % 2 == 0) g.fill(x - 3, ry - 3, left + 158, ry + ROW_H - 3, 0x18000000);
            g.drawString(this.font, stat.displayName().getString(), x, ry, INK, false);
            String value = stat.hasCap() ? d.stat(stat) + "/" + stat.cap() : String.valueOf(d.stat(stat));
            g.drawString(this.font, value, left + 150 - this.font.width(value), ry, INK, false);
            if (mouseX >= x - 3 && mouseX < left + 158 && mouseY >= ry - 3 && mouseY < ry + ROW_H - 3) hovered = stat;
        }
        int ty = y + Stat.values().length * ROW_H + 4;
        g.fill(x - 3, ty - 4, left + 158, ty - 3, LINE);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.total", d.allocatedPoints()), x, ty, INK, false);

        // right column: who you are
        int rx = left + 172, ry = top + 10;
        line(g, rx, ry, Component.translatable("screen.shinobiarts.clan").append(" ").append(d.getClan().displayName().getString()));
        boolean clanHovered = mouseX >= rx && mouseX < left + W - 6 && mouseY >= ry - 2 && mouseY < ry + 10;
        String village = d.getVillage().isEmpty() ? Component.translatable("screen.shinobiarts.no_village").getString() : Villages.name(d.getVillage());
        String role = d.isKage() ? " (Kage)" : d.isAdvisor() ? " (" + Component.translatable("title.shinobiarts.advisor").getString() + ")" : "";
        line(g, rx, ry += 13, Component.translatable("screen.shinobiarts.affiliation").append(" " + village + role));
        line(g, rx, ry += 13, Component.translatable("screen.shinobiarts.rank_line").append(" ").append(d.getRank().displayName().getString())
                .append(Component.literal("  (" + d.getRank().levelCap() + ")").withStyle(s -> s.withColor(0x5E6455))));
        line(g, rx, ry += 13, Component.translatable("screen.shinobiarts.ryo_line").append(" " + PlayerDataManager.formatRyo(d.getRyo())));
        line(g, rx, ry += 18, Component.translatable("screen.shinobiarts.nature_release"));
        int ix = rx;
        for (ChakraNature n : ChakraNature.NATURES) {
            if (!d.hasNature(n)) continue;
            g.blit(n.icon(), ix, ry + 11, 14, 14, 0, 0, 64, 64, 64, 64);
            ix += 16;
        }
        if (ix == rx) g.drawString(this.font, "-", rx, ry + 13, INK_SOFT, false);
        line(g, rx, ry += 32, Component.translatable("screen.shinobiarts.kekkei_genkai"));
        List<Component> eyes = new ArrayList<>();
        if (d.getSharinganStage() > 0) eyes.add(Dojutsu.sharinganName(d.getSharinganStage()));
        if (d.availableDojutsu().contains(Dojutsu.BYAKUGAN)) eyes.add(Dojutsu.byakuganName());
        if (eyes.isEmpty()) eyes.add(Component.literal("-"));
        for (Component e : eyes) {
            g.drawString(this.font, e.getString(), rx + 4, ry += 11, e.getStyle().getColor() == null ? INK_SOFT : 0xFFA01818, false);
        }

        if (hovered != null) {
            g.renderComponentTooltip(this.font, List.of(hovered.description(), effectText(hovered, d).withStyle(ChatFormatting.GRAY)), mouseX, mouseY);
        } else if (clanHovered) {
            // the clan's rarity and every bonus it gives
            List<Component> tip = new ArrayList<>();
            int rollsLeft = Math.max(0, Config.i(Config.CLAN_ROLLS) - d.getClanRolls());
            tip.add(d.getClan().displayName().withStyle(ChatFormatting.BOLD));
            if (d.getClan() == com.shinobiarts.ninja.Clan.NONE) {
                tip.add(Component.translatable("screen.shinobiarts.clan_roll_hint", rollsLeft).withStyle(ChatFormatting.YELLOW));
            } else {
                tip.add(d.getClan().rarityText());
                tip.addAll(d.getClan().describe());
                if (!d.isClanClaimed() && rollsLeft > 0) {
                    tip.add(Component.translatable("screen.shinobiarts.clan_unclaimed", rollsLeft).withStyle(ChatFormatting.YELLOW));
                }
            }
            g.renderComponentTooltip(this.font, tip, mouseX, mouseY);
        }
    }

    private void renderJutsuPage(GuiGraphics g, NinjaData d) {
        int x = left + 8;
        int cost = Config.i(Config.JUTSU_UPGRADE_COST), max = Config.i(Config.JUTSU_MAX_UPGRADES);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.tab_jutsu"), x, top + 8, INK_SOFT, false);
        Component points = Component.translatable("screen.shinobiarts.jutsu_points", d.getJutsuPoints());
        g.drawString(this.font, points, left + W - 8 - this.font.width(points), top + 8, d.getJutsuPoints() >= cost ? 0xFF1E7A2E : INK, false);
        int percent = Math.round(Config.f(Config.JUTSU_UPGRADE_DAMAGE) * 100);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.jutsu_hint", cost, percent, max), x, top + 20, INK_SOFT, false);
        g.fill(x - 3, top + 31, left + W - 5, top + 32, LINE);

        if (shownJutsu.isEmpty()) {
            Component none = Component.translatable("screen.shinobiarts.jutsu_none");
            g.drawString(this.font, none, left + W / 2 - this.font.width(none) / 2, top + 90, INK_SOFT, false);
            return;
        }
        for (int i = 0; i < shownJutsu.size(); i++) {
            Jutsu jutsu = shownJutsu.get(i);
            int ry = top + 38 + i * JROW_H;
            if (i % 2 == 0) g.fill(x - 3, ry - 4, left + W - 5, ry + JROW_H - 4, 0x18000000);
            RenderSystem.enableBlend();
            g.blit(jutsu.release().icon(), x, ry - 2, 13, 13, 0, 0, 64, 64, 64, 64);
            String name = this.font.plainSubstrByWidth(ShinobiHud.shortName(jutsu), 122);
            g.drawString(this.font, name, x + 17, ry + 1, INK, false);
            int level = d.jutsuUpgrade(jutsu.id());
            int px = left + 150;
            if (max <= 8) {
                for (int k = 0; k < max; k++) {
                    int bx = px + k * 7;
                    g.fill(bx, ry + 1, bx + 6, ry + 7, 0xFF8E9980);
                    g.fill(bx + 1, ry + 2, bx + 5, ry + 6, k < level ? 0xFFD9A21E : 0xFFF4F6EE);
                }
            } else {
                g.drawString(this.font, level + "/" + max, px, ry + 1, INK, false);
            }
            String bonus = "+" + Math.round((d.jutsuDamageMultiplier(jutsu.id()) - 1f) * 100) + "%";
            g.drawString(this.font, bonus, left + W - 76 - this.font.width(bonus), ry + 1, level > 0 ? 0xFF1E7A2E : INK_SOFT, false);
        }
        List<Jutsu> all = upgradeableJutsu(d);
        int pages = Math.max(1, (all.size() + JROWS - 1) / JROWS);
        if (pages > 1) {
            String p = (jutsuPage + 1) + "/" + pages;
            g.drawString(this.font, p, left + W / 2 - this.font.width(p) / 2, top + H - 17, INK_SOFT, false);
        }
    }

    private void renderTeamPage(GuiGraphics g) {
        CompoundTag team = ClientNinjaData.team();
        int x = left + 8, y = top + 8;
        g.drawString(this.font, Component.translatable("screen.shinobiarts.team"), x, y, INK_SOFT, false);
        g.fill(left + 164, top + 8, left + 165, top + H - 8, LINE);
        y += 16;
        if (team.contains("Name")) {
            ListTag members = team.getList("Members", Tag.TAG_COMPOUND);
            g.drawString(this.font, team.getString("Name"), x, y, 0xFF1F4F9F, false);
            g.drawString(this.font, Component.translatable("screen.shinobiarts.team_members", members.size(), team.getInt("Max")),
                    x, y += 12, INK_SOFT, false);
            y += 16;
            for (int i = 0; i < members.size(); i++) {
                CompoundTag m = members.getCompound(i);
                boolean online = m.getBoolean("Online");
                g.fill(x, y + 1, x + 6, y + 7, online ? 0xFF3FAF46 : 0xFF8A8F80);
                g.drawString(this.font, m.getString("Name") + (m.getBoolean("Leader") ? " ★" : ""), x + 10, y, online ? INK : INK_SOFT, false);
                y += 14;
            }
        } else {
            g.drawString(this.font, Component.translatable("screen.shinobiarts.team_none"), x, y, INK_SOFT, false);
            if (team.contains("Invite")) {
                g.drawString(this.font, Component.translatable("screen.shinobiarts.team_invite", team.getString("Invite")), x, y += 16, 0xFF1E7A2E, false);
                g.drawString(this.font, "/team accept", x, y += 11, 0xFF7A4E00, false);
            }
        }
        int rx = left + 172, ry = top + 10;
        for (String cmd : new String[]{"/team create <name>", "/team invite <player>", "/team kick <name>", "/team leave", "/team disband"}) {
            g.drawString(this.font, cmd, rx, ry, INK_SOFT, false);
            ry += 12;
        }
        g.drawString(this.font, Component.translatable("screen.shinobiarts.team_max", Config.i(Config.TEAM_MAX)), rx, ry + 8, INK_SOFT, false);
    }

    private void line(GuiGraphics g, int x, int y, Component text) {
        g.drawString(this.font, text, x, y, INK, false);
    }

    /** A pale panel with a soft border and rounded corners. */
    static void panel(GuiGraphics g, int x, int y, int w, int h) {
        rounded(g, x - 2, y - 2, w + 4, h + 4, 4, BORDER);
        rounded(g, x, y, w, h, 3, LIGHT);
        rounded(g, x + 1, y + 1, w - 2, h - 2, 3, PANEL);
    }

    static void rounded(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int inset = (int) Math.round(r - Math.sqrt(r * r - (r - i - 0.5) * (r - i - 0.5)));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    /** What the current points in a stat are doing, e.g. "+3.5 fist damage". */
    private static MutableComponent effectText(Stat stat, NinjaData d) {
        int p = d.stat(stat);
        return switch (stat) {
            case TAIJUTSU -> Component.translatable("stat.shinobiarts.effect.taijutsu", fmt(p * Config.d(Config.TAIJUTSU_PER_POINT)));
            case KENJUTSU -> Component.translatable("stat.shinobiarts.effect.kenjutsu", fmt(p * Config.d(Config.KENJUTSU_PER_POINT)));
            case GENJUTSU -> Component.translatable("stat.shinobiarts.effect.genjutsu", Math.round((d.genjutsuMultiplier() - 1f) * 100));
            case MEDICAL -> Component.translatable("stat.shinobiarts.effect.medical", fmt(p * Config.d(Config.HEALTH_PER_MEDICAL)));
            case SPEED -> Component.translatable("stat.shinobiarts.effect.speed", Math.round(p * Config.d(Config.SPEED_PER_POINT) * 100));
            case NINJUTSU -> Component.translatable("stat.shinobiarts.effect.ninjutsu", (int) d.maxChakra());
            case SENJUTSU -> Component.translatable("stat.shinobiarts.effect.senjutsu", (int) d.maxSenjutsu());
        };
    }

    private static String fmt(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.format("%.1f", v);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
