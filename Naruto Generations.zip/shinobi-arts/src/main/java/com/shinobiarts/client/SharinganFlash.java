package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.shinobiarts.ShinobiArts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * The Sharingan "flash": when your Sharingan switches on or evolves, its eyes fade in across the middle of the
 * screen over a short darkening, then fade away (about 1.8 seconds).
 */
public final class SharinganFlash {
    private static final int TEX_W = 512, TEX_H = 160;
    private static final long FADE_IN = 220, HOLD = 900, FADE_OUT = 650;
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[5];

    static {
        for (int i = 1; i <= 4; i++) TEXTURES[i] = new ResourceLocation(ShinobiArts.MODID, "textures/gui/sharingan_flash_" + i + ".png");
    }

    private static long start = -1;
    private static int stage = 3;

    private SharinganFlash() {}

    public static void play(int sharinganStage) {
        stage = Math.max(1, Math.min(4, sharinganStage));
        start = System.currentTimeMillis();
    }

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height);

    private static void render(GuiGraphics g, int width, int height) {
        if (start < 0 || Minecraft.getInstance().options.hideGui) return;
        long t = System.currentTimeMillis() - start;
        if (t > FADE_IN + HOLD + FADE_OUT) {
            start = -1;
            return;
        }
        float alpha = t < FADE_IN ? t / (float) FADE_IN : t < FADE_IN + HOLD ? 1f : 1f - (t - FADE_IN - HOLD) / (float) FADE_OUT;
        alpha = Math.max(0f, Math.min(1f, alpha));
        g.fill(0, 0, width, height, ((int) (alpha * 110) << 24));
        int w = Math.min(width - 20, (int) (width * 0.72f));
        int h = w * TEX_H / TEX_W;
        int x = (width - w) / 2, y = (height - h) / 2 - height / 10;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.setColor(1f, 1f, 1f, alpha);
        g.blit(TEXTURES[stage], x, y, w, h, 0, 0, TEX_W, TEX_H, TEX_W, TEX_H);
        g.setColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}
