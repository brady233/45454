package com.shinobiarts.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/**
 * Client side of the Sharingan helmet: renders it with its own head model that sits just over the skin's
 * hat layer (instead of the bulky helmet model), so the eyes look painted onto the face.
 */
public final class SharinganArmorModel implements IClientItemExtensions {
    public static final SharinganArmorModel INSTANCE = new SharinganArmorModel();
    private HumanoidModel<LivingEntity> model;

    private SharinganArmorModel() {}

    @Override
    public HumanoidModel<?> getHumanoidArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<?> original) {
        if (slot != EquipmentSlot.HEAD) return original;
        if (model == null) model = new HumanoidModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(ClientSetup.SHARINGAN_LAYER));
        return model;
    }
}
