package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.SharinganItem;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * Draws Sharingan eyes on the face of a player (or shadow clone) whose Sharingan is switched on,
 * in the look of its current stage (1-3 tomoe or Mangekyou).
 */
public class SharinganEyesLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[5];

    static {
        for (int i = 1; i <= 4; i++) TEXTURES[i] = texture(i);
    }

    private final HumanoidModel<T> eyes;

    public SharinganEyesLayer(RenderLayerParent<T, M> parent, EntityModelSet models) {
        super(parent);
        this.eyes = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHARINGAN_LAYER));
    }

    public static ResourceLocation texture(int stage) {
        return new ResourceLocation(ShinobiArts.MODID, "textures/models/eyes/sharingan_" + Math.max(1, Math.min(4, stage)) + ".png");
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        int stage = ClientEyes.stage(entity);
        if (stage <= 0 || entity.isInvisible()) return;
        // The Sharingan helmet already draws the eyes (in the wearer's stage) at the same spot.
        if (entity.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof SharinganItem) return;
        getParentModel().copyPropertiesTo(eyes);
        eyes.setAllVisible(false);
        eyes.head.visible = true;
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURES[stage]));
        eyes.renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
    }
}
