package com.shinobiarts.entity;

import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * A chakra projectile (fireball, water bullet, water dragon...). It has no model:
 * it is drawn entirely with particles on the client, so no textures are needed.
 */
public class JutsuProjectile extends ThrowableProjectile {
    public enum Kind { FIRE_BALL, FIRE_SMALL, WATER_BULLET, WATER_DRAGON, RASENGAN, RASENSHURIKEN }

    private static final EntityDataAccessor<Byte> KIND = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.BYTE);
    private static final DustParticleOptions WATER_DUST = new DustParticleOptions(new Vector3f(0.2f, 0.5f, 1.0f), 1.4f);
    private static final DustParticleOptions WATER_DUST_BIG = new DustParticleOptions(new Vector3f(0.15f, 0.4f, 0.95f), 2.4f);
    private static final DustParticleOptions CHAKRA_DUST = new DustParticleOptions(new Vector3f(0.45f, 0.8f, 1.0f), 1.3f);
    private static final DustParticleOptions WIND_DUST = new DustParticleOptions(new Vector3f(0.85f, 0.95f, 1.0f), 1.6f);
    private static final int MAX_LIFE = 80;

    private float damage = 5f;

    public JutsuProjectile(EntityType<? extends JutsuProjectile> type, Level level) {
        super(type, level);
    }

    public static JutsuProjectile shoot(ServerPlayer owner, Kind kind, float speed, float yawOffset, float damage) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        Vec3 eye = owner.getEyePosition();
        p.setPos(eye.x, eye.y - 0.3, eye.z);
        p.setKind(kind);
        p.damage = damage;
        p.shootFromRotation(owner, owner.getXRot(), owner.getYRot() + yawOffset, 0.0f, speed, 0.5f);
        owner.level().addFreshEntity(p);
        return p;
    }

    /**
     * Fired by any creature (e.g. a shadow clone) at a target; the damage is credited to {@code owner}
     * (the clone's player), so it counts as theirs and never hits them or their own clones.
     */
    public static JutsuProjectile shootAt(LivingEntity shooter, @javax.annotation.Nullable Entity owner, Kind kind, float speed,
                                          float damage, LivingEntity target) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), shooter.level());
        p.setOwner(owner != null ? owner : shooter);
        Vec3 eye = shooter.getEyePosition();
        p.setPos(eye.x, eye.y - 0.3, eye.z);
        p.setKind(kind);
        p.damage = damage;
        Vec3 aim = target.getBoundingBox().getCenter().subtract(p.position());
        p.shoot(aim.x, aim.y, aim.z, speed, 0.5f);
        shooter.level().addFreshEntity(p);
        return p;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(KIND, (byte) 0);
    }

    public Kind getKind() {
        int i = this.entityData.get(KIND);
        return Kind.values()[Mth.clamp(i, 0, Kind.values().length - 1)];
    }

    public void setKind(Kind kind) {
        this.entityData.set(KIND, (byte) kind.ordinal());
    }

    private boolean isFire() {
        Kind k = getKind();
        return k == Kind.FIRE_BALL || k == Kind.FIRE_SMALL;
    }

    @Override
    protected float getGravity() {
        return 0.0f;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            spawnTrail();
            return;
        }
        if (isRemoved()) return;
        if (isFire() && isInWaterOrBubble()) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 10, 0.2, 0.2, 0.2, 0.02);
            playSound(SoundEvents.FIRE_EXTINGUISH, 0.6f, 1.2f);
            discard();
        } else if (tickCount > MAX_LIFE) {
            discard();
        }
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        if (!super.canHitEntity(target)) return false;
        Entity owner = getOwner();
        if (owner == null) return true;
        if (target == owner) return false;
        return !(target instanceof ShadowClone clone && owner.getUUID().equals(clone.getOwnerUUID()));
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity target = result.getEntity();
        Kind kind = getKind();
        if (kind == Kind.FIRE_SMALL) {
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            target.setSecondsOnFire(4);
        } else if (kind == Kind.WATER_BULLET) {
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            target.clearFire();
            JutsuUtil.push(target, getDeltaMovement().normalize().scale(0.8).add(0, 0.2, 0));
        }
        // FIRE_BALL, WATER_DRAGON, RASENGAN and RASENSHURIKEN deal area damage in impact().
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide && !isRemoved()) {
            impact(result.getLocation());
            discard();
        }
    }

    private void impact(Vec3 pos) {
        ServerLevel level = (ServerLevel) level();
        Entity owner = getOwner();
        switch (getKind()) {
            case FIRE_BALL -> {
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 3.5)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.setSecondsOnFire(6);
                }
                level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 2, 0.5, 0.5, 0.5, 0.0);
                level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 80, 1.2, 1.0, 1.2, 0.08);
                level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y, pos.z, 20, 1.0, 0.8, 1.0, 0.02);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 1.0f, 1.3f);
                if (JutsuUtil.griefing(level, owner)) placeFire(level, pos, 2, 8);
            }
            case FIRE_SMALL -> {
                level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 15, 0.3, 0.3, 0.3, 0.03);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.FIRECHARGE_USE, getSoundSource(), 0.5f, 1.4f);
                if (JutsuUtil.griefing(level, owner)) placeFire(level, pos, 0, 1);
            }
            case WATER_BULLET -> {
                level.sendParticles(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, 30, 0.4, 0.4, 0.4, 0.1);
                level.sendParticles(WATER_DUST, pos.x, pos.y, pos.z, 15, 0.3, 0.3, 0.3, 0.0);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_SPLASH, getSoundSource(), 0.7f, 1.5f);
            }
            case RASENGAN -> {
                Vec3 push = getDeltaMovement().lengthSqr() > 1e-4 ? getDeltaMovement().normalize() : Vec3.ZERO;
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 2.2)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    JutsuUtil.push(e, push.scale(1.8).add(0, 0.5, 0));
                }
                level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
                level.sendParticles(CHAKRA_DUST, pos.x, pos.y, pos.z, 50, 0.6, 0.6, 0.6, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 20, 0.5, 0.3, 0.5, 0.08);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 0.8f, 1.5f);
            }
            case RASENSHURIKEN -> {
                // A sphere of wind blades: heavy damage all around the impact, slowing and throwing everything out.
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 5.0)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
                    Vec3 away = e.position().subtract(pos);
                    away = away.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : away.normalize();
                    JutsuUtil.push(e, away.scale(1.3).add(0, 0.6, 0));
                }
                level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, pos.x, pos.y, pos.z, 40, 2.5, 1.8, 2.5, 0.0);
                level.sendParticles(WIND_DUST, pos.x, pos.y, pos.z, 120, 2.8, 2.0, 2.8, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 60, 2.5, 1.5, 2.5, 0.1);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 1.6f, 0.8f);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ELYTRA_FLYING, getSoundSource(), 1.2f, 1.6f);
            }
            case WATER_DRAGON -> {
                Vec3 push = getDeltaMovement().lengthSqr() > 1e-4 ? getDeltaMovement().normalize() : Vec3.ZERO;
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 4.0)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.clearFire();
                    Vec3 away = e.position().subtract(pos).multiply(1, 0, 1);
                    away = away.lengthSqr() < 1e-4 ? push : away.normalize();
                    JutsuUtil.push(e, away.scale(1.2).add(push.scale(0.8)).add(0, 0.5, 0));
                }
                level.sendParticles(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, 150, 2.0, 1.2, 2.0, 0.3);
                level.sendParticles(WATER_DUST_BIG, pos.x, pos.y, pos.z, 60, 1.5, 1.0, 1.5, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 20, 1.5, 0.5, 1.5, 0.05);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, getSoundSource(), 1.5f, 0.6f);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_SPLASH, getSoundSource(), 1.5f, 0.8f);
            }
        }
    }

    private void placeFire(ServerLevel level, Vec3 pos, int radius, int attempts) {
        RandomSource r = level.getRandom();
        for (int i = 0; i < attempts; i++) {
            BlockPos bp = BlockPos.containing(pos.x + (radius == 0 ? 0 : r.nextInt(radius * 2 + 1) - radius),
                    pos.y + 0.5, pos.z + (radius == 0 ? 0 : r.nextInt(radius * 2 + 1) - radius));
            for (int k = 0; k < 3; k++, bp = bp.below()) {
                if (BaseFireBlock.canBePlacedAt(level, bp, Direction.UP)) {
                    level.setBlockAndUpdate(bp, BaseFireBlock.getState(level, bp));
                    break;
                }
            }
        }
    }

    /** Client-side visuals. */
    private void spawnTrail() {
        Level level = level();
        RandomSource r = this.random;
        double x = getX(), y = getY() + getBbHeight() / 2, z = getZ();
        switch (getKind()) {
            case FIRE_BALL -> {
                for (int i = 0; i < 8; i++) {
                    level.addParticle(ParticleTypes.FLAME, x + (r.nextDouble() - 0.5) * 0.9, y + (r.nextDouble() - 0.5) * 0.9,
                            z + (r.nextDouble() - 0.5) * 0.9, 0, 0.01, 0);
                }
                level.addParticle(ParticleTypes.LARGE_SMOKE, x, y, z, 0, 0.02, 0);
                if (r.nextInt(3) == 0) level.addParticle(ParticleTypes.LAVA, x, y, z, 0, 0, 0);
            }
            case FIRE_SMALL -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(ParticleTypes.FLAME, x + (r.nextDouble() - 0.5) * 0.3, y + (r.nextDouble() - 0.5) * 0.3,
                            z + (r.nextDouble() - 0.5) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.SMOKE, x, y, z, 0, 0, 0);
            }
            case WATER_BULLET -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(WATER_DUST, x + (r.nextDouble() - 0.5) * 0.3, y + (r.nextDouble() - 0.5) * 0.3,
                            z + (r.nextDouble() - 0.5) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.SPLASH, x, y, z, 0, 0, 0);
            }
            case RASENGAN -> {
                for (int i = 0; i < 6; i++) {
                    double a = (tickCount * 0.9 + i * Math.PI / 3);
                    level.addParticle(CHAKRA_DUST, x + Math.cos(a) * 0.3, y + Math.sin(a * 1.3) * 0.25, z + Math.sin(a) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.ENCHANTED_HIT, x, y, z, 0, 0, 0);
            }
            case RASENSHURIKEN -> {
                for (int i = 0; i < 4; i++) {
                    double a = tickCount * 1.2 + i * Math.PI / 2;
                    level.addParticle(WIND_DUST, x + Math.cos(a) * 1.2, y, z + Math.sin(a) * 1.2, 0, 0, 0);
                    level.addParticle(WIND_DUST, x + Math.cos(a) * 0.6, y, z + Math.sin(a) * 0.6, 0, 0, 0);
                }
                level.addParticle(CHAKRA_DUST, x, y, z, 0, 0, 0);
                if (r.nextInt(2) == 0) level.addParticle(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0, 0);
            }
            case WATER_DRAGON -> {
                for (int i = 0; i < 10; i++) {
                    level.addParticle(WATER_DUST_BIG, x + (r.nextDouble() - 0.5) * 1.6, y + (r.nextDouble() - 0.5) * 1.6,
                            z + (r.nextDouble() - 0.5) * 1.6, 0, 0, 0);
                }
                for (int i = 0; i < 4; i++) {
                    level.addParticle(ParticleTypes.SPLASH, x + (r.nextDouble() - 0.5) * 1.2, y + (r.nextDouble() - 0.5) * 1.2,
                            z + (r.nextDouble() - 0.5) * 1.2, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.CLOUD, x, y, z, 0, 0, 0);
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putByte("Kind", (byte) getKind().ordinal());
        tag.putFloat("Damage", damage);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(KIND, tag.getByte("Kind"));
        this.damage = tag.getFloat("Damage");
    }
}
