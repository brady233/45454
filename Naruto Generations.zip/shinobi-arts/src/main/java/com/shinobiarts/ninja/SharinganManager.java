package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.item.SharinganEyeItem;
import com.shinobiarts.network.EyesPacket;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

/**
 * The Sharingan's life cycle: evolution (1 -> 2 -> 3 tomoe by level, then the Mangekyou after a near-death
 * experience), its combat strength per stage, eyes taken in PvP, and implanting a taken eye.
 * Stages never skip: each one is unlocked in order, and nobody holds a stage their level can't support.
 */
public final class SharinganManager {
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.85f, 0.05f, 0.08f), 1.4f);
    private static final float[] DODGE = {0f, 0.12f, 0.18f, 0.25f, 0.32f};
    private static final double[] COPY_RANGE = {0, 12, 18, 24, 32};

    private SharinganManager() {}

    /** Level needed to reach a tomoe stage (1-3). */
    public static int levelFor(int stage) {
        return switch (stage) {
            case 2 -> Config.i(Config.SHARINGAN_2_LEVEL);
            case 3 -> Config.i(Config.SHARINGAN_3_LEVEL);
            case Dojutsu.MANGEKYOU -> Config.i(Config.MANGEKYOU_LEVEL);
            default -> 1;
        };
    }

    /** Highest tomoe stage (1-3) a player of this level can hold. */
    public static int maxTomoeFor(int level) {
        if (level >= levelFor(3)) return 3;
        if (level >= levelFor(2)) return 2;
        return 1;
    }

    // ---------------------------------------------------------------- evolution

    /** Called on login and after level-ups: unlocks the next tomoe stages in order. */
    public static void checkEvolution(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null || d.getSharinganStage() <= 0 || d.getSharinganStage() >= 3) return;
        while (d.getSharinganStage() < 3 && d.getLevel() >= levelFor(d.getSharinganStage() + 1)) {
            evolve(player, d, d.getSharinganStage() + 1);
        }
    }

    /** Every few ticks: a 3-tomoe user at the required level who survives at ~5% health awakens the Mangekyou. */
    public static void checkMangekyou(ServerPlayer player, NinjaData d) {
        if (d.getSharinganStage() != 3 || d.getLevel() < levelFor(Dojutsu.MANGEKYOU) || !player.isAlive()) return;
        if (player.getHealth() <= player.getMaxHealth() * Config.d(Config.MANGEKYOU_HEALTH)) {
            evolve(player, d, Dojutsu.MANGEKYOU);
        }
    }

    private static void evolve(ServerPlayer player, NinjaData d, int stage) {
        d.setSharinganStage(stage);
        boolean mangekyou = stage == Dojutsu.MANGEKYOU;
        player.sendSystemMessage(Component.translatable(mangekyou ? "message.shinobiarts.mangekyou_awakened" : "message.shinobiarts.sharingan_evolved",
                Dojutsu.sharinganName(stage)).withStyle(ChatFormatting.RED));
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                mangekyou ? SoundEvents.WITHER_SPAWN : SoundEvents.ELDER_GUARDIAN_CURSE, SoundSource.PLAYERS, mangekyou ? 0.6f : 0.5f, 1.4f);
        player.serverLevel().sendParticles(RED, player.getX(), player.getEyeY(), player.getZ(), 40, 0.4, 0.3, 0.4, 0.0);
        ModNetwork.sync(player);
        broadcastEyes(player);
    }

    // ---------------------------------------------------------------- strength per stage

    /** Chance to dodge a hit while the Sharingan is on (Genjutsu raises it, up to 50%). */
    public static float dodgeChance(int stage, float genjutsuMultiplier) {
        return Math.min(0.5f, DODGE[Math.max(0, Math.min(Dojutsu.MANGEKYOU, stage))] * genjutsuMultiplier);
    }

    /** How far away a jutsu can be seen and copied. */
    public static double copyRange(NinjaData d) {
        return COPY_RANGE[Math.max(0, Math.min(Dojutsu.MANGEKYOU, d.getSharinganStage()))] * d.genjutsuMultiplier();
    }

    // ---------------------------------------------------------------- showing the eyes to other players

    /** The stage others should see on this player's face (0 = eyes off). */
    public static int visibleStage(NinjaData d) {
        return d.isSharinganActive() ? d.getSharinganStage() : 0;
    }

    public static void broadcastEyes(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), new EyesPacket(player.getId(), visibleStage(d)));
    }

    /** Tells one player what another player's eyes look like (when they come into view). */
    public static void sendEyes(ServerPlayer viewer, ServerPlayer target) {
        NinjaData d = NinjaData.get(target);
        if (d == null) return;
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer), new EyesPacket(target.getId(), visibleStage(d)));
    }

    // ---------------------------------------------------------------- taking and implanting eyes

    /**
     * A rewarded PvP kill of a Sharingan user: the killer takes one of their eyes (as an item).
     * Born Uchiha keep their bloodline Sharingan; anyone else loses theirs.
     */
    public static void onPvpKill(ServerPlayer killer, ServerPlayer victim) {
        if (!Config.b(Config.EYE_THEFT)) return;
        NinjaData vd = NinjaData.get(victim);
        if (vd == null || vd.getSharinganStage() <= 0) return;
        int stage = vd.getSharinganStage();
        ItemStack eye = SharinganEyeItem.create(stage, victim.getGameProfile().getName());
        if (!killer.getInventory().add(eye) || !eye.isEmpty()) killer.drop(eye, false);
        killer.sendSystemMessage(Component.translatable("message.shinobiarts.eye_taken", victim.getGameProfile().getName(),
                Dojutsu.sharinganName(stage)).withStyle(ChatFormatting.DARK_RED));
        if (vd.getClan() != Clan.UCHIHA) {
            vd.setSharinganStage(0);
            victim.sendSystemMessage(Component.translatable("message.shinobiarts.eye_lost", killer.getGameProfile().getName())
                    .withStyle(ChatFormatting.DARK_RED));
            ModNetwork.sync(victim);
            broadcastEyes(victim);
        }
    }

    /**
     * Implants a taken eye. You get the eye's stage, limited by what your level can handle
     * (a Mangekyou eye needs the Mangekyou level). Returns true if the eye was used up.
     */
    public static boolean implant(ServerPlayer player, int eyeStage) {
        NinjaData d = NinjaData.get(player);
        if (d == null || eyeStage <= 0) return false;
        int allowed = eyeStage == Dojutsu.MANGEKYOU && d.getLevel() >= levelFor(Dojutsu.MANGEKYOU)
                ? Dojutsu.MANGEKYOU : Math.min(eyeStage, maxTomoeFor(d.getLevel()));
        int current = d.getSharinganStage();
        if (current >= eyeStage) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.eye_no_better").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        if (allowed <= current) {
            int needed = eyeStage == Dojutsu.MANGEKYOU && current == 3 ? levelFor(Dojutsu.MANGEKYOU) : levelFor(current + 1);
            player.displayClientMessage(Component.translatable("message.shinobiarts.eye_too_strong", needed).withStyle(ChatFormatting.RED), true);
            return false;
        }
        d.setSharinganStage(allowed);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.eye_implanted", Dojutsu.sharinganName(allowed))
                .withStyle(ChatFormatting.RED));
        if (allowed < eyeStage) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.eye_limited",
                    eyeStage == Dojutsu.MANGEKYOU && allowed == 3 ? levelFor(Dojutsu.MANGEKYOU) : levelFor(allowed + 1)).withStyle(ChatFormatting.GRAY));
        }
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ELDER_GUARDIAN_CURSE, SoundSource.PLAYERS, 0.5f, 1.2f);
        player.serverLevel().sendParticles(RED, player.getX(), player.getEyeY(), player.getZ(), 30, 0.3, 0.2, 0.3, 0.0);
        ModNetwork.sync(player);
        broadcastEyes(player);
        return true;
    }
}
