package com.shinobiarts.event;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.command.ShinobiCommand;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.jutsu.JutsuEffects;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.jutsu.NinjaTicker;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.NinjaDataProvider;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.Stat;
import com.shinobiarts.registry.ModDamage;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommonEvents {
    private static final ResourceLocation NINJA_DATA_ID = ShinobiArts.id("ninja_data");

    private CommonEvents() {}

    // ---------------------------------------------------------------- player data lifecycle

    @SubscribeEvent
    public static void attachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            // No invalidate listener on purpose: when a player dies, Forge invalidates the old body's capabilities
            // before the Clone event runs. With a listener that invalidation was permanent, so reviveCaps() could
            // not bring the data back, the respawned player started blank and the whole HUD disappeared.
            event.addCapability(NINJA_DATA_ID, new NinjaDataProvider());
        }
    }

    /** Copies data to the new player object after death or returning from the End. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        Player original = event.getOriginal();
        original.reviveCaps();
        NinjaData oldData = NinjaData.get(original);
        NinjaData newData = NinjaData.get(event.getEntity());
        if (oldData != null && newData != null) {
            newData.load(oldData.save());
            if (event.isWasDeath()) {
                newData.resetStates();
                newData.setChakra(newData.maxChakra());
            }
        } else {
            ShinobiArts.LOGGER.error("Could not copy ninja data for {} (old: {}, new: {})",
                    event.getEntity().getName().getString(), oldData != null, newData != null);
        }
        original.invalidateCaps();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        if (!data.isInitialized()) {
            data.init(player.getRandom());
            welcome(player, data);
            ReleaseItem.give(player, ChakraNature.NONE); // the starter release, empty until jutsu are learned
            giveStarterKit(player);
        }
        data.setCharging(false);
        data.clearCombat(); // anyone who logged out in combat was already killed for it
        com.shinobiarts.village.VillageManager.refresh(player);
        com.shinobiarts.village.VillageManager.refreshTitles(player);
        PlayerDataManager.applyStatEffects(player);
        ModNetwork.sync(player);
        SharinganManager.checkEvolution(player);
        SharinganManager.broadcastEyes(player);
        com.shinobiarts.team.TeamManager.get(player.server).onLogin(player);
    }

    /** Every new ninja starts with a Frog Wallet and 3 kunai. */
    private static void giveStarterKit(ServerPlayer player) {
        for (ItemStack stack : new ItemStack[]{new ItemStack(com.shinobiarts.registry.ModItems.FROG_WALLET.get()),
                new ItemStack(com.shinobiarts.registry.ModItems.KUNAI.get(), 3)}) {
            player.getInventory().add(stack);
            if (!stack.isEmpty()) player.drop(stack, false);
        }
        player.sendSystemMessage(Component.translatable("message.shinobiarts.starter_kit").withStyle(ChatFormatting.AQUA));
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) com.shinobiarts.team.TeamManager.get(player.server).onLogout(player);
    }

    /** When a player comes into view, tell the viewer whether that player's Sharingan is on. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer viewer && event.getTarget() instanceof ServerPlayer target) {
            SharinganManager.sendEyes(viewer, target);
        }
    }

    /**
     * Tells a player which clan they rolled, its rarity and every bonus it gives. Rare and Mythic rolls are announced
     * to the whole server (config: announceRareClans).
     */
    public static void announceClan(ServerPlayer player, NinjaData data, boolean broadcast) {
        Clan clan = data.getClan();
        player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_result", clan.displayName(), clan.rarityText())
                .withStyle(ChatFormatting.GOLD));
        for (Component line : clan.describe()) {
            player.sendSystemMessage(Component.literal(" - ").withStyle(ChatFormatting.DARK_GRAY).append(line));
        }
        boolean rare = clan.rarity() == Clan.Rarity.RARE || clan.rarity() == Clan.Rarity.MYTHIC;
        if (broadcast && rare && Config.b(Config.ANNOUNCE_RARE_CLANS)) {
            boolean mythic = clan.rarity() == Clan.Rarity.MYTHIC;
            Component msg = Component.translatable(mythic ? "message.shinobiarts.clan_born_mythic" : "message.shinobiarts.clan_born",
                    player.getDisplayName(), clan.displayName(), clan.rarity().displayName()).withStyle(mythic ? ChatFormatting.GOLD : ChatFormatting.AQUA);
            for (ServerPlayer p : player.server.getPlayerList().getPlayers()) {
                p.sendSystemMessage(msg);
                if (mythic) p.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 0.8f);
            }
        }
    }

    /** "Roll your clan with /clanroll!" with a clickable button. */
    public static void clanRollIntro(ServerPlayer player) {
        player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_intro", Config.i(Config.CLAN_ROLLS))
                .withStyle(ChatFormatting.GOLD)
                .append(com.shinobiarts.command.ClanCommand.button("message.shinobiarts.clanroll_intro_button", "/clanroll", ChatFormatting.AQUA)));
    }

    private static void welcome(ServerPlayer player, NinjaData data) {
        clanRollIntro(player);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.paper").withStyle(ChatFormatting.YELLOW));
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.keys").withStyle(ChatFormatting.YELLOW));
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            PlayerDataManager.applyStatEffects(player);
            if (!event.isEndConquered()) player.setHealth(player.getMaxHealth());
            ModNetwork.sync(player);
            SharinganManager.broadcastEyes(player); // dying turns the Sharingan off; clear it from everyone's view
        }
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ModNetwork.sync(player);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.side == LogicalSide.SERVER && event.player instanceof ServerPlayer player) {
            NinjaTicker.tick(player);
        }
    }

    @SubscribeEvent
    public static void registerCommands(RegisterCommandsEvent event) {
        ShinobiCommand.register(event.getDispatcher());
        com.shinobiarts.command.TeamCommand.register(event.getDispatcher());
        com.shinobiarts.command.VillageCommand.register(event.getDispatcher());
        com.shinobiarts.command.ClanCommand.register(event.getDispatcher());
    }

    // ---------------------------------------------------------------- combat

    /** Defensive techniques: Palm Rotation, Substitution and the Sharingan's dodge. */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.getEntity() == null || source.getEntity() == player) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        long now = player.level().getGameTime();

        if (data.getRotationUntil() > now) {
            event.setCanceled(true);
            return;
        }
        if (data.getSubstitutionUntil() > now) {
            event.setCanceled(true);
            data.setSubstitutionUntil(0);
            JutsuEffects.triggerSubstitution(player, source.getEntity());
            ModNetwork.sync(player);
            return;
        }
        if (data.isSharinganActive()) {
            float chance = SharinganManager.dodgeChance(data.getSharinganStage(), data.genjutsuMultiplier());
            if (player.getRandom().nextFloat() < chance) {
                event.setCanceled(true);
                player.serverLevel().sendParticles(ParticleTypes.CRIT, player.getX(), player.getY() + 1, player.getZ(), 10, 0.3, 0.5, 0.3, 0.1);
                JutsuUtil.sound(player.level(), player.position(), SoundEvents.PLAYER_ATTACK_NODAMAGE, 1.0f, 1.4f);
                player.displayClientMessage(Component.translatable("message.shinobiarts.dodged").withStyle(ChatFormatting.RED), true);
            }
        }
        // clan evasion: Iburi smoke, Hozuki water body, Otsutsuki...
        float dodge = data.getClan().buffs().dodge();
        if (!event.isCanceled() && dodge > 0 && player.getRandom().nextFloat() < dodge) {
            event.setCanceled(true);
            player.serverLevel().sendParticles(ParticleTypes.POOF, player.getX(), player.getY() + 1, player.getZ(), 12, 0.3, 0.5, 0.3, 0.02);
            JutsuUtil.sound(player.level(), player.position(), SoundEvents.PLAYER_ATTACK_NODAMAGE, 1.0f, 1.2f);
            player.displayClientMessage(Component.translatable("message.shinobiarts.clan_dodged").withStyle(ChatFormatting.AQUA), true);
        }
    }

    /** Clan defenses: less damage from projectiles (Kazekage sand) and from falls (Iburi smoke). */
    @SubscribeEvent
    public static void onPlayerHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        com.shinobiarts.ninja.ClanBuffs buffs = data.getClan().buffs();
        DamageSource source = event.getSource();
        if (buffs.projectileResist() > 0 && source.is(DamageTypeTags.IS_PROJECTILE)) {
            event.setAmount(event.getAmount() * (1f - buffs.projectileResist()));
        }
        if (buffs.fallResist() > 0 && source.is(DamageTypeTags.IS_FALL)) {
            event.setAmount(event.getAmount() * (1f - buffs.fallResist()));
        }
    }

    /** Offensive bonuses: Taijutsu fists, Kenjutsu swords, Rasengan, Gentle Fist and Sage Mode jutsu. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        DamageSource source = event.getSource();
        if (!(source.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        LivingEntity target = event.getEntity();

        // Sage Mode empowers every jutsu.
        if (source.is(ModDamage.JUTSU) && data.isSageMode()) {
            event.setAmount(event.getAmount() * (1f + Config.f(Config.SAGE_MODE_JUTSU_BONUS)));
            return;
        }

        if (!source.is(DamageTypes.PLAYER_ATTACK) || source.getDirectEntity() != player) return;
        long now = player.level().getGameTime();
        boolean changed = false;

        ItemStack weapon = player.getMainHandItem();
        boolean fists = weapon.isEmpty() || weapon.getItem() instanceof ReleaseItem;
        if (fists && data.stat(Stat.TAIJUTSU) > 0) {
            event.setAmount(event.getAmount() + data.stat(Stat.TAIJUTSU) * Config.f(Config.TAIJUTSU_PER_POINT));
        } else if (weapon.getItem() instanceof SwordItem && data.stat(Stat.KENJUTSU) > 0) {
            event.setAmount(event.getAmount() + data.stat(Stat.KENJUTSU) * Config.f(Config.KENJUTSU_PER_POINT));
        }

        // clan melee bonuses, chakra drain and on-hit effects
        com.shinobiarts.ninja.ClanBuffs buffs = data.getClan().buffs();
        float mult = 1f + buffs.melee() + (fists ? buffs.fist() : 0f) + (weapon.getItem() instanceof SwordItem ? buffs.sword() : 0f);
        if (mult != 1f) event.setAmount(event.getAmount() * mult);
        if (buffs.drainOnHit() > 0 && target instanceof ServerPlayer victim && victim != player) {
            float drained = PlayerDataManager.drainChakra(victim, buffs.drainOnHit());
            if (drained > 0) {
                data.addChakra(drained);
                changed = true;
            }
        }
        for (java.util.Map.Entry<com.shinobiarts.ninja.ClanBuffs.OnHit, Float> e : buffs.onHitEffects().entrySet()) {
            if (player.getRandom().nextFloat() < e.getValue()) {
                target.addEffect(new MobEffectInstance(e.getKey().effect(), e.getKey().ticks(), e.getKey().amplifier()), player);
            }
        }

        if (data.getRasenganUntil() > now) {
            event.setAmount(event.getAmount() + JutsuUtil.dmg(14f) * data.jutsuBonus(com.shinobiarts.jutsu.Jutsus.RASENGAN));
            data.setRasenganUntil(0);
            JutsuEffects.rasenganHit(player, target);
            changed = true;
        }

        if (data.getActiveDojutsu() == Dojutsu.BYAKUGAN) {
            // Gentle Fist: strikes the chakra points directly.
            event.setAmount(event.getAmount() * 1.4f);
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            Vec3 c = target.getBoundingBox().getCenter();
            player.serverLevel().sendParticles(ParticleTypes.ENCHANTED_HIT, c.x, c.y, c.z, 12, 0.3, 0.3, 0.3, 0.2);
            if (target instanceof ServerPlayer victim) PlayerDataManager.drainChakra(victim, 15f);
        }

        if (changed) ModNetwork.sync(player);
    }

    /** No fall damage right after a Ninja Jump. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data != null && data.getFallProtectUntil() > player.level().getGameTime()) {
            event.setDistance(Math.min(event.getDistance(), 3.0f));
        }
    }
}
